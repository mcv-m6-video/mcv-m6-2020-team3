"""
example
{'frame': 100, 'left': 931, 'top': 78, 'width': 82, 'height': 68, 'confidence': 0.99}
Note, frame starts from 1.
"""
import pickle
import sys
import json

import matplotlib.pyplot as plt
import cv2
import os
import numpy as np
from tqdm import tqdm
import matplotlib.patches as mpatches
from AICityIterator import AICityIterator
from track_ext import Track_ext
from copy import deepcopy
from week5.detection import Detection
import motmetrics as mm

from week5.optical_flow_tracking import TrackingOF
from week5.utilities.multi_camera  import *



def read_homography_matrix(hom_path):
    with open(hom_path) as f:
        first_line = True
        for line in f:
            if first_line:
                useful_line = line[19:]
                matrix = [[float(num) for num in row.split(' ')] for row in useful_line.split(';')]
                print(matrix)
                first_line = False
    return matrix


def visualize_tracks(image, frame_tracks, colors, display=False, export_frames=False, export_path="test.png"):
    """
    Draw on an image the bounding boxes on frame_tracks, with a different color for each track
    THE OPENCV VERSION IS MORE EFFICIENT

    """
    fig, ax = plt.subplots()
    ax.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB), cmap='gray')
    plt.xticks([]), plt.yticks([])

    for id in frame_tracks.keys():
        bbox = frame_tracks[id]
        minc, minr, maxc, maxr = bbox['bbox']
        rect = mpatches.Rectangle((minc, minr), maxc - minc + 1, maxr - minr + 1, fill=False, edgecolor=colors[id], linewidth=2)
        ax.add_patch(rect)

    if display:
        plt.show()

    if export_frames:
        plt.savefig(export_path, bbox_inches='tight', pad_inches=0, dpi=72)


def visualize_tracks_opencv(image, frame_id, save_path, frame_tracks, colors, display=False, export_frames=False):
    """
    Draw on an image the bounding boxes on frame_tracks, with a different color for each track

    """
    for id in frame_tracks.keys():
        bbox = frame_tracks[id]
        minc, minr, maxc, maxr = bbox['bbox']
        cv2.rectangle(image, (minc, minr), (maxc, maxr), colors[id]*255, 20)

    # for id in frame_tracks.keys():
    #     bbox = frame_tracks[id]
    #     minc, minr, maxc, maxr = bbox['bbox']
    #     cv2.rectangle(image, (minc, minr), (maxc, maxr), colors[id]*255, 20)


    if display:
        plt.show(image)

    if export_frames:
        image = cv2.resize(image, (0, 0), fx=0.25, fy=0.25)
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        print (save_path + '/frame_' + str(frame_id))
        path = save_path + '/frame_' + str(frame_id)
        # cv2.imwrite(path , image)
        # cv2.imwrite(path, image, [int(cv2.IMWRITE_PNG_COMPRESSION), 4, int(cv2.IMWRITE_JPEG_QUALITY), 70])
        plt.imshow(image)
        plt.savefig(path + '.png')
        # plt.show()
        plt.close()

def predict_position(image, track):
    width = 0
    height = 0
    xtl_new = 0
    ytl_new = 0
    time = track.time_since_update + 1
    for n, detection in enumerate(track.detections):
        width += detection.bbox[2] - detection.bbox[0]
        height += detection.bbox[3] - detection.bbox[1]
        if n>0:
            xtl_new += detection.bbox[0] - track.detections[n - 1].bbox[0]
            ytl_new += detection.bbox[1] - track.detections[n - 1].bbox[1]

    width = width/len(track.detections)
    height = height/len(track.detections)
    xtl_new = track.detections[-1].bbox[0] + time*xtl_new/len(track.detections)
    ytl_new = track.detections[-1].bbox[1] + time*ytl_new / len(track.detections)

    next_detection_bbox = [xtl_new, ytl_new, xtl_new + width, ytl_new + height]

    # if track.detections[-1].label == 'bike':
    #     fig, ax = plt.subplots()
    #     ax.imshow(image, cmap='gray')
    #     minc, minr, maxc, maxr = next_detection_bbox
    #     rect = mpatches.Rectangle((minc, minr), maxc - minc + 1, maxr - minr + 1, fill=False, edgecolor='red',
    #                                   linewidth=2)
    #     ax.add_patch(rect)
    #
    #     plt.show()

    return next_detection_bbox


def color_check(image, bbox_1, bbox_2):
    image_1 = image[int(bbox_1[1]):int(bbox_1[3]), int(bbox_1[0]):int(bbox_1[2]), :]
    image_2 = image[int(bbox_2[1]):int(bbox_2[3]), int(bbox_2[0]):int(bbox_2[2]), :]

    u = rgb_histogram(image_1)
    v = rgb_histogram(image_2)

    if intersection(u, v) < 0.5:
        return True
    return False
def rgb_histogram(image):
    h, w, c = image.shape

    descriptors = []
    for i in range(c):
        hist = np.histogram(image[:, :, i], bins=10, range=(0, 255))[0]
        hist = hist / (h * w)  # normalize
        descriptors.append(np.array(hist, dtype=np.float32))

    return descriptors

def intersection(u, v):
    """
    Compare histograms based on their intersection.

    Args:
        u (ndarray): 1D array of type np.float32 containing image descriptors.
        v (ndarray): 1D array of type np.float32 containing image descriptors.

    Returns:
        float: distance between histograms.
    """
    return 1 - cv2.compareHist(np.array(u), np.array(v), cv2.HISTCMP_INTERSECT)

def ratio_check(bbox_1, bbox_2):
    box_h_1, box_w_1 = bbox_1[2] - bbox_1[0], bbox_1[3] - bbox_1[1]
    box_h_2, box_w_2 = bbox_2[2] - bbox_2[0], bbox_2[3] - bbox_2[1]
    if (box_h_1 / box_w_1) > 1.2 * (box_h_2 / box_w_2) or (box_h_1 / box_w_1) < 0.8 * (box_h_2 / box_w_2):
        return False
    return True


def bbox_iou(bboxA, bboxB):
    # compute the intersection over union of two bboxes

    # Format of the bboxes is [tly, tlx, bry, brx, ...], where tl and br
    # indicate top-left and bottom-right corners of the bbox respectively.

    # determine the coordinates of the intersection rectangle
    xA = max(bboxA[1], bboxB[1])
    yA = max(bboxA[0], bboxB[0])
    xB = min(bboxA[3], bboxB[3])
    yB = min(bboxA[2], bboxB[2])

    # compute the area of intersection rectangle
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)

    # compute the area of both bboxes
    bboxAArea = (bboxA[2] - bboxA[0] + 1) * (bboxA[3] - bboxA[1] + 1)
    bboxBArea = (bboxB[2] - bboxB[0] + 1) * (bboxB[3] - bboxB[1] + 1)

    iou = interArea / float(bboxAArea + bboxBArea - interArea)

    # return the intersection over union value
    return iou


def get_IoU_relation(image, track, last_bbox, unused_detections, IoU_relation):
    for detection in unused_detections:
        IoU = bbox_iou(last_bbox, detection.bbox)
        if IoU > 0 and color_check(image, last_bbox, detection.bbox) and ratio_check(last_bbox, detection.bbox):
            IoU_relation.append((track, detection, IoU))
    return IoU_relation

def update_tracks(image, tracks, detections, frame_tracks):
    unused_detections = detections
    unused_tracks = [track.id for track in tracks]
    IoU_relations = []
    for track in tracks:
        if track.time_since_update < 20:
            if track.time_since_update > 0 and len(track.detections) > 1:
                last_bbox = predict_position(image, track)
            else:
                last_bbox = track.detections[-1].bbox
            IoU_relations=get_IoU_relation(image, track, last_bbox, unused_detections, IoU_relations)
    for relation in sorted(IoU_relations, key=lambda relation: relation[2], reverse=True):
        track = relation[0]
        match_detection = relation[1]
        if (match_detection in unused_detections and track.id in unused_tracks):
            unused_detections.remove(match_detection)
            unused_tracks.remove(track.id)
            track.detections.append(match_detection)
            frame_tracks[track.id] = dict(bbox=match_detection.bbox, confidence=match_detection.confidence)
            track.hits += 1
            if track.time_since_update == 0:
                track.hit_streak += 1
            track.time_since_update = 0

    for ut in unused_tracks:
        track = next((x for x in tracks if x.id == ut), None)
        track.time_since_update +=1
        track.hit_streak = 0

    return tracks, unused_detections, frame_tracks

def obtain_new_tracks(tracks, unused_detections, max_track, frame_tracks):
    for detection in unused_detections:
        tracks.append(Track_ext(max_track+1, [detection], 0, 1, 1))
        frame_tracks[max_track+1] = dict(bbox= detection.bbox, confidence= detection.confidence)

        max_track += 1

    return tracks, max_track, frame_tracks

def find_tracking_extended(seq, cam, detections_all,gt_list,  video_length, optical_flow = False, of_track= TrackingOF, idf1 = True, display = False, export_frames = False, save_pkl=True, name_pkl='', save_json=False):
    embeddings = {}
    detects_to_embed = {}
    colors = np.random.rand(500, 3)  # used only for display
    tracks = []
    new_detections = []
    of_detections = []
    max_track = -1
    iterator = AICityIterator(seq, cam, video_length)
    if idf1:
        acc = mm.MOTAccumulator(auto_id=True)
    # for i, imgPath in tqdm(range(video_length)):
    # for i in tqdm(range(video_length)):

    for i, imgPath in tqdm(enumerate(iterator), total=len(iterator)):
        frame_id = i+1
        frame_tracks = {}
        # detections_on_frame = [x for x in detections_all if x.frame == frame_id]
        # gt_on_frame = [x for x in gt_list if x.frame == frame_id]
        gt_on_frame = [x for x in gt_list if x.frame == frame_id]
        # detections_on_frame = [x for x in detections_all if x["frame"] == frame_id]
        detections_on_frame = [x for x in detections_all if x.frame == frame_id]

        image = cv2.imread(imgPath)
        tracks, unused_detections, frame_tracks = update_tracks(image, tracks, detections_on_frame, frame_tracks)
        tracks, max_track, frame_tracks = obtain_new_tracks(tracks, unused_detections, max_track, frame_tracks)
        if display and frame_id % 2 == 0 and frame_id < 200:
            visualize_tracks(image, frame_tracks, colors, display=display)

        if export_frames:
            print(export_frames)
            visualize_tracks_opencv(image, frame_id, save_path, frame_tracks, colors, export_frames=export_frames)
        # IDF1 computing
        detec_bboxes = []
        detec_ids = []
        for key, value in frame_tracks.items():
            detec_ids.append(key)
            bbox = value['bbox']
            conf = value['confidence']
            detec_bboxes.append(bbox)
            cd = Detection(frame_id, 'car', bbox[0], bbox[1], bbox[2] - bbox[0],
                                            bbox[3] - bbox[1], conf, track_id=key,
                                            histogram=rgb_histogram(image[int(bbox[1]):int(bbox[3]), int(bbox[0]):int(bbox[2]), :]))
            minc, minr, maxc, maxr = cd.bbox
            image_car = image[minr:maxr, minc:maxc, :]
            image_car_resized = cv2.resize(image_car, (64, 64))
            detects_to_embed[cd] = image_car_resized
            new_detections.append(cd)
        if optical_flow:
            of_detections.append(of_track.check_optical_flow(new_detections, frame_id))

        gt_bboxes = []
        gt_ids = []
        for gt in gt_on_frame:
            gt_bboxes.append(gt.bbox)
            gt_ids.append(gt.track_id)

        mm_gt_bboxes = [[(bbox[0]+bbox[2])/2, (bbox[1]+bbox[3])/2, bbox[2]-bbox[0], bbox[3]-bbox[1]] for bbox in gt_bboxes]
        mm_detec_bboxes = [[(bbox[0]+bbox[2])/2, (bbox[1]+bbox[3])/2, bbox[2] - bbox[0], bbox[3] - bbox[1]] for bbox in detec_bboxes]


        if idf1:
            distances_gt_det = mm.distances.iou_matrix(mm_gt_bboxes, mm_detec_bboxes, max_iou=1.)
            acc.update(gt_ids, detec_ids, distances_gt_det)

        if idf1:
            print(acc.mot_events)
            mh = mm.metrics.create()
            summary = mh.compute(acc, metrics=mm.metrics.motchallenge_metrics, name='acc')
            with open("results/metrics.txt", "a") as f:
                f.write(summary.to_string() + "\n")
            print(summary)

        if save_pkl:
            with open('detections' + name_pkl + '.pkl', 'wb') as f:
                pickle.dump(new_detections, f, protocol=2)
            with open('tracks' + name_pkl + '.pkl', 'wb') as f:
                pickle.dump(tracks, f, protocol=2)
            with open('embeddings' + name_pkl + '.pkl', 'wb') as f:
                pickle.dump(embeddings, f, protocol=2)

        # if False:
        #     with open('detections' + name_pkl + '.json', 'wb') as f:
        #         json.dumps(new_detections, f)
        #     with open('tracks' + name_pkl + '.json', 'wb') as f:
        #         json.dumps(tracks, f)

        return new_detections, tracks, embeddings
def read_detections(path):
    # [frame, -1, left, top, width, height, conf, -1, -1, -1]
    frame_detections = []

    with open(path) as f:
        for line in f.readlines():
            parts = line.split(',')
            frame_id = int(parts[0])
            # while frame_id > len(frame_detections):
            #     frame_detections.append([])

            tl_x = int(float(parts[2]))
            tl_y = int(float(parts[3]))
            width = int(float(parts[4]))
            height = int(float(parts[5]))

            frame_detections.append(Detection(frame_id, 'car', tl_x, tl_y, width, height, 1))

    return frame_detections


def read_annotations_from_xml(annotation_path,cam):
    """
    Arguments:
    capture: frames from video, opened as cv2.VideoCapture
    root: parsed xml annotations as ET.parse(annotation_path).getroot()
    """
    root = ET.parse(annotation_path).getroot()

    ground_truths = []
    tracks = []
    images = []
    num = 0
    iterator = AICityIterator(seq, cam, video_length)
    for i, imgPath in tqdm(enumerate(iterator), total=len(iterator)):
        frame_id = i+1
        image = cv2.imread(imgPath)

        #for now: (take only numannotated annotated frames)
        #if num > numannotated:
        #    break

        images.append(image)
        for track in root.findall('track'):
            gt_id = track.attrib['id']
            label = track.attrib['label']
            box = track.find("box[@frame='{0}']".format(str(num)))

            #if box is not None and (label == 'car' or label == 'bike'):    # Read cars and bikes
            if box is not None and label == 'car':                          # Read cars

                if box.attrib['occluded'] == '1':                           # Discard occluded
                    continue

                #if label == 'car' and box[0].text == 'true':               # Discard parked cars
                #    continue

                frame = int(box.attrib['frame'])
                #if frame < 534:
                #    continue

                xtl = int(float(box.attrib['xtl']))
                ytl = int(float(box.attrib['ytl']))
                xbr = int(float(box.attrib['xbr']))
                ybr = int(float(box.attrib['ybr']))
                ground_truths.append(Detection(frame, label, xtl, ytl, xbr - xtl + 1, ybr - ytl + 1, 1, gt_id))
                track_corresponding = [t for t in tracks if t.id == gt_id]
                if len(track_corresponding) > 0:
                    track_corresponding[0].detections.append(Detection(frame+1, label, xtl, ytl, xbr - xtl + 1, ybr - ytl + 1, 1))
                else:
                    track_corresponding = Track_ext(gt_id, [Detection(frame+1, label, xtl, ytl, xbr - xtl + 1, ybr - ytl + 1, 1)])
                    tracks.append(track_corresponding)
        num += 1

    return ground_truths, tracks


def read_annotations_from_txt(gt_path, analyze=False):
    """
    Read annotations from the txt files
    Arguments:
    gt_path: path to .txt file
    :returns: list of Detection
    """
    ground_truths_list = list()
    if analyze:
        max_w = 0
        min_w = 2000
        max_h = 0
        min_h = 2000
        min_ratio = 100
        max_ratio = 0
    with open(gt_path) as f:
        for line in f:
            data = line.split(',')
            #if int(data[0])-1 < 534:
            #    continue
            ground_truths_list.append(Detection(int(data[0])-1, 'car', int(float(data[2])), int(float(data[3])), int(float(data[4])), int(float(data[5])),float(data[6]), track_id=int(data[1])))

            if analyze:
                if int(data[4]) < min_w: min_w = int(data[4])
                if int(data[4]) > max_w: max_w = int(data[4])
                if int(data[5]) < min_h: min_h = int(data[5])
                if int(data[5]) > max_h: max_h = int(data[5])
                if int(data[5])/int(data[4]) > max_ratio: max_ratio = int(data[5])/int(data[4])
                if int(data[5])/int(data[4]) < min_ratio: min_ratio = int(data[5])/int(data[4])
    # print('width: [{0}, {1}]'.format(min_w, max_w))
    # print('height: [{0}, {1}]'.format(min_h, max_h))
    # print('ratio: [{0}, {1}]'.format(min_ratio, max_ratio))

    return ground_truths_list


def read_annotations_file(gt_path,cam):
    tracks_gt_list = []
    if (gt_path.endswith('.txt')):
        annotations_list = read_annotations_from_txt(gt_path)
    elif (gt_path.endswith('.xml')):
        annotations_list, tracks_gt_list = read_annotations_from_xml(gt_path, cam)
    else:
        raise Exception('Incompatible filetype')

    return annotations_list, tracks_gt_list

def compute_mAP(groundtruth_list_original, detections_list, IoU_threshold=0.5, verbose = True):

    groundtruth_list = deepcopy(groundtruth_list_original)

    # Sort detections by confidence
    detections_list.sort(key=lambda x: x.confidence, reverse=True)
    # Save number of groundtruth labels
    groundtruth_size = len(groundtruth_list)

    TP = 0; FP = 0; FN = 0
    precision = list(); recall = list()

    # to compute mAP
    max_precision_per_step = list()
    threshold = 1; checkpoint = 0
    temp = 1000

    for n, detection in enumerate(detections_list):
        match_flag = False
        if threshold != temp:
            #print(threshold)
            temp = threshold

        # Get groundtruth of the target frame
        gt_on_frame = [x for x in groundtruth_list if x.frame == detection.frame]
        gt_bboxes = [(o.bbox, o.confidence) for o in gt_on_frame]

        #print(gt_bboxes)
        for gt_bbox in gt_bboxes:
            #print(gt_bbox[0])
            #print(detection.bbox)
            iou = bbox_iou(gt_bbox[0], detection.bbox)
            if iou > IoU_threshold and gt_bbox[1] > 0.9:
                match_flag = True
                TP += 1
                gt_used = next((x for x in groundtruth_list if x.frame == detection.frame and x.bbox == gt_bbox[0]), None)
                gt_used.confidence = 0
                break

        if match_flag == False:
            FP += 1

        # Save metrics
        precision.append(TP/(TP+FP))
        if groundtruth_size:
            recall.append(TP/groundtruth_size)

    for n, r in enumerate(reversed(recall)):
        if r < threshold or n == len(precision)-1:
            if r > threshold-0.1:
                #print(n), print(r)
                if n > 0:
                    max_precision_per_step.append(max(precision[-n:]))
                else:
                    #max_precision_per_step.append(precision[len(precision)-1])
                    max_precision_per_step.append(0)
                threshold -= 0.1
            else:
                max_precision_per_step.append(0)
                threshold -= 0.1

    #plot_precision_recall_curve(precision, recall, max_precision_per_step)

    # Check false negatives
    groups = defaultdict(list)
    for obj in groundtruth_list:
        groups[obj.frame].append(obj)
    grouped_groundtruth_list = groups.values()

    for groundtruth in grouped_groundtruth_list:
        detection_on_frame = [x for x in detections_list if x.frame == groundtruth[0].frame]
        detection_bboxes = [o.bbox for o in detection_on_frame]

        groundtruth_bboxes = [o.bbox for o in groundtruth]

        TP_temp, FN_temp, FP_temp = performance_accumulation_window(detection_bboxes, groundtruth_bboxes)
        FN += FN_temp

    if verbose:
        print("TP={} FN={} FP={}".format(TP, FN, FP))

    recall = 0
    precision = 0
    F1_score = 0
    if TP > 0:
        precision = float(TP) / float(TP + FP)
        recall = float(TP) / float(TP + FN)
        F1_score = 2 * recall * precision / (recall + precision)
    #print(TP+FP)
    #print("precision:{}".format(precision))
    #print("recall:{}".format(recall))
    #print(max_precision_per_step)
    mAP = sum(max_precision_per_step)/11
    if verbose:
        print("mAP: {}".format(mAP))

    return precision, recall, max_precision_per_step, F1_score, mAP


def performance_accumulation_window(detections, annotations):
    """
    performance_accumulation_window()

    Function to compute different performance indicators (True Positive,
    False Positive, False Negative) at the object level.

    Objects are defined by means of rectangular windows circumscribing them.
    Window format is [ struct(x,y,w,h)  struct(x,y,w,h)  ... ] in both
    detections and annotations.

    An object is considered to be detected correctly if detection and annotation
    windows overlap by more of 50%

       function [TP,FN,FP] = PerformanceAccumulationWindow(detections, annotations)

       Parameter name      Value
       --------------      -----
       'detections'        List of windows marking the candidate detections
       'annotations'       List of windows with the ground truth positions of the objects

    The function returns the number of True Positive (TP), False Positive (FP),
    False Negative (FN) objects
    """

    detections_used = np.zeros(len(detections))
    annotations_used = np.zeros(len(annotations))
    TP = 0
    for ii in range(len(annotations)):
        for jj in range(len(detections)):
            if (detections_used[jj] == 0) & (bbox_iou(annotations[ii], detections[jj]) > 0.5):
                TP = TP + 1
                detections_used[jj] = 1
                annotations_used[ii] = 1

    FN = np.sum(annotations_used == 0)
    FP = np.sum(detections_used == 0)

    return [TP, FN, FP]


def bboxes_correspondences(gt_detections, timestamps, framenum, fps):
    correspondences = []

    #Assume cameras are in order of ascendent timestamp
    for frame in range(framenum[0]+1):
        for detec in gt_detections[0][0]:
            for idx in len(detec.detections):
                if detec.detections[idx]['frame'] == frame:
                    print(detec)
        # detecs_frame_0 = [detec ]

        for cam in range(1, len(framenum)):
            if frame >= int(timestamps[cam]*fps) and frame <= framenum[cam]:
                detecs_frame_1 = [detec for detec in gt_detections[0][1] if detec.frame == frame - int(timestamps[cam]*fps)]

                for detec_0 in detecs_frame_0:
                    matches = [detec_1 for detec_1 in detecs_frame_1 if detec_1.track_id == detec_0.track_id]
                    if len(matches) == 1:

                        correspondences.append((detec_0.bbox, matches[0].bbox))

    return correspondences

def get_timestamp(dataset_path, sequence):
    file_path = os.path.join(dataset_path, 'cam_timestamp', sequence + ".txt")
    timestamps = []

    with open(file_path, "r") as f:
        for line in f:
            timestamps.append(float(line.split()[1]))

    return timestamps


def get_framenum(dataset_path, sequence):
    file_path = os.path.join(dataset_path, 'cam_framenum', sequence + ".txt")
    framenum = []

    with open(file_path, "r") as f:
        for line in f:
            framenum.append(int(line.split()[1]))

    return framenum


if __name__ == "__main__":

    test_path = "../Datasets/AIC20_track3/train/S03/"
    dataset_path = "../Datasets/AIC20_track3/"
    path_experiment = "week5"
    fps = 10
    cameras_path = ["../Datasets/AIC20_track3/train/S03/c010/frames",
                    "../Datasets/AIC20_track3/train/S03/c011/frames",
                    "../Datasets/AIC20_track3/train/S03/c012/frames",
                    "../Datasets/AIC20_track3/train/S03/c013/frames",
                    "../Datasets/AIC20_track3/train/S03/c014/frames",
                    "../Datasets/AIC20_track3/train/S03/c015/frames"]
    crop_center = True if "-c" in sys.argv else False
    use_of = False if "-n" in sys.argv else True
    display = False
    export_frames = True
    load_pkl = True
    tracked_detections = {}
    tracks_by_camera = {}
    embeddings = {}
    homography_cameras = {}
    groundtruth_list = {}
    optical_flow = False
    of_track = TrackingOF
    video_path = {}
    trywthgt = False
    seq = sys.argv[1] if len(sys.argv) >= 3 else 'S03'
    detector = "det_ssd512.txt"
    # camera = 'c010'
    save_pkl = True

    save_json = True
    camera_list = ['c010', 'c011', 'c012', 'c013', 'c014', 'c015']
    video_length_list = {
        'c010': 2141,
        'c011': 2279,
        'c012': 2422,
        'c013': 2415,
        'c014': 2332,
        'c015': 1928}
    timestamps = get_timestamp(dataset_path, seq)
    framenum = get_framenum(dataset_path, seq)
    embeddings = {}
    detects_to_embed = {}
    colors = np.random.rand(500, 3)  # used only for display
    tracks = []
    new_detections = []
    of_detections = []
    max_track = -1
    idf1 = True
    # for camera in camera_list:
    #     save_path = "output/"+camera
    #     if idf1:
    #         acc = mm.MOTAccumulator(auto_id=True)
    #     print(camera)
#     hom_path = "../Datasets/AIC20_track3/train/S03/" + camera + "/calibration.txt"
# homography_cameras = read_homography_matrix(hom_path)

    #     det_path = "../Datasets/AIC20_track3/train/S03/" + camera + "/det/"
    #     name_pkl = seq + camera
    #     # detections = detections_all_camera[camera]
    #     print("Reading gt...")
    #     gt = test_path + camera + '/gt/gt.txt'
    #     print (gt)
    #     # tracks_gt_list = read_annotations_file(gt)
    #     # detections_list, _ = read_annotations_file(det_path + detector, camera )
    #     gt_list, _ = read_annotations_file(gt, camera)
    #     # video_length = len(tracks_gt_list)
    #     print (camera)
    #     video_length = video_length_list[camera]
    #     print(video_length)
    #     iterator = AICityIterator(seq, camera, video_length)
    #
    #     print("Reading pkl")
    #     detections_filename = "detections/detections_S03_"+ camera + ".pkl"
    #     with open(detections_filename, 'rb') as p:
    #         detections_list = pickle.load(p)
    #         p.close()
    #     # detections_list.sort(key=lambda x: x['frame'])
    #     # print(detections_list)
    #     detections_all = []
    #     for x in range(0, len(detections_list)):
    #         # print (detections_list[x])
    #         # print(detections_list[x]['frame'])
    #         detections_all.append(Detection(detections_list[x]['frame'], 'car', detections_list[x]['left'],
    #                                         detections_list[x]['top'], detections_list[x]['width'], detections_list[x]['height'],
    #                                         detections_list[x]['confidence']))
    #
    #     for i, imgPath in tqdm(enumerate(iterator), total=len(iterator)):
    #         frame_id = i + 1
    #         frame_tracks = {}
    #         # detections_on_frame = [x for x in detections_all if x.frame == frame_id]
    #         # gt_on_frame = [x for x in gt_list if x.frame == frame_id]
    #         gt_on_frame = [x for x in gt_list if x.frame == frame_id]
    #         # detections_on_frame = [x for x in detections_all if x["frame"] == frame_id]
    #         detections_on_frame = [x for x in detections_all if x.frame == frame_id]
    #
    #         image = cv2.imread(imgPath)
    #         tracks, unused_detections, frame_tracks = update_tracks(image, tracks, detections_on_frame, frame_tracks)
    #         tracks, max_track, frame_tracks = obtain_new_tracks(tracks, unused_detections, max_track, frame_tracks)
    #         if display and frame_id % 2 == 0 and frame_id < 200:
    #             visualize_tracks(image, frame_tracks, colors, display=display)
    #
    #         if export_frames:
    #             visualize_tracks_opencv(image,frame_id, save_path ,frame_tracks, colors, export_frames=export_frames)
    #         # IDF1 computing
    #         detec_bboxes = []
    #         detec_ids = []
    #         for key, value in frame_tracks.items():
    #             detec_ids.append(key)
    #             bbox = value['bbox']
    #             conf = value['confidence']
    #             detec_bboxes.append(bbox)
    #             cd = Detection(frame_id, 'car', bbox[0], bbox[1], bbox[2] - bbox[0],
    #                            bbox[3] - bbox[1], conf, track_id=key,
    #                            histogram=rgb_histogram(image[int(bbox[1]):int(bbox[3]), int(bbox[0]):int(bbox[2]), :]))
    #             minc, minr, maxc, maxr = cd.bbox
    #             image_car = image[minr:maxr, minc:maxc, :]
    #             image_car_resized = cv2.resize(image_car, (64, 64))
    #             detects_to_embed[cd] = image_car_resized
    #             new_detections.append(cd)
    #         if optical_flow:
    #             of_detections.append(of_track.check_optical_flow(new_detections, frame_id))
    #
    #         gt_bboxes = []
    #         gt_ids = []
    #         for gt in gt_on_frame:
    #             gt_bboxes.append(gt.bbox)
    #             gt_ids.append(gt.track_id)
    #
    #         mm_gt_bboxes = [[(bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2, bbox[2] - bbox[0], bbox[3] - bbox[1]] for
    #                         bbox in gt_bboxes]
    #         mm_detec_bboxes = [[(bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2, bbox[2] - bbox[0], bbox[3] - bbox[1]]
    #                            for bbox in detec_bboxes]
    #
    #         if idf1:
    #             distances_gt_det = mm.distances.iou_matrix(mm_gt_bboxes, mm_detec_bboxes, max_iou=1.)
    #             acc.update(gt_ids, detec_ids, distances_gt_det)
    #
    #     # if idf1:
    #     #     print(acc.mot_events)
    #     #     mh = mm.metrics.create()
    #     #     summary = mh.compute(acc, metrics=mm.metrics.motchallenge_metrics, name='acc')
    #     #     with open("results/metrics.txt", "a") as f:
    #     #         f.write(summary.to_string() + "\n")
    #     #     print(summary)
    #
    #     if save_pkl:
    #         with open('pkl/detections' + name_pkl + '.pkl', 'wb') as f:
    #             pickle.dump(new_detections, f, protocol=2)
    #         with open('pkl/tracks' + name_pkl + '.pkl', 'wb') as f:
    #             pickle.dump(tracks, f, protocol=2)
    #         with open('pkl/embeddings' + name_pkl + '.pkl', 'wb') as f:
    #             pickle.dump(embeddings, f, protocol=2)
    #     tracked_detections = new_detections
    #     tracks_by_camera = tracks
    #
    #     # if json:
    #     #     with open('detections' + name_pkl + '.json', 'wb') as f:
    #     #         json.dumps(new_detections, f)
    #     #     with open('tracks' + name_pkl + '.json', 'wb') as f:
    #     #         json.dumps(tracks, f)
    #
    #     # tracked_detections, tracks_by_camera, embeddings = find_tracking_extended(seq, camera, detections_list_all, tracks_gt_list, video_length, optical_flow = False, of_track= TrackingOF, idf1=False, display=display_frames, export_frames=export_frames, save_pkl=True, name_pkl=seq+ camera, save_json=True)
    #     compute_mAP(groundtruth_list, tracked_detections)
    # #
    for cam_num, camera in enumerate(camera_list):
        hom_path = "../Datasets/AIC20_track3/train/S03/" + camera + "/calibration.txt"
        homography_cameras[cam_num] = read_homography_matrix(hom_path)
        # detections_filename = "detectionsS031"  + ".pkl"
        # #embedding_filename = "embeddingsS03" + camera + ".pkl"
        # tracks_filename = "tracksS031"  + ".pkl"
        gt_filename = "track_gt_de.pkl"
        detections_filename = "detections_frcnn_S03_" + camera + ".pkl"
        #embedding_filename = "embeddingsS03" + camera + ".pkl"
        tracks_filename = "tracks_S03_" + camera + "_10.pkl"
        # gt_filename = "gt_tracks_S03_" + camera + ".pkl"
        with open(detections_filename, 'rb') as p:
            print("Reading tracked detections from pkl")
            tracked_detections[cam_num] = pickle.load(p)
            # print(tracked_detections[cam_num])
            print("Tracked detections loaded\n")

        with open(tracks_filename, 'rb') as p:
            print("Reading tracks from pkl")
            tracks_by_camera[cam_num] = pickle.load(p)
            print("Tracks loaded\n")

        with open(gt_filename, 'rb') as p:
            print("Reading tracks from pkl")
            groundtruth_list[cam_num] = pickle.load(p)
            print("Tracks loaded\n")
    # correspondences = bboxes_correspondences(groundtruth_list, timestamps, framenum, fps)
    multicamera_tracks = match_tracks(tracks_by_camera, homography_cameras, timestamps, framenum,
                                       fps, video_path, path_experiment)
    # match_tracks_by_frame(tracked_detections, homography_cameras, timestamps, framenum, fps, cameras_path[0] , cameras_path[1] , correspondences, seq, camera, video_length)

    acc = mm.MOTAccumulator(auto_id=True)
    for cam_num, camera in enumerate(cameras_path):

        tracks = tracks_by_camera[cam_num]
        detections_list = []
        for track in tracks:
            for detection in track.detections:
                detections_list.append(detection)

        gt_list = groundtruth_list[cam_num]
        for n_frame in range(framenum[cam_num] + 1):

            detec_bboxes = []
            detec_ids = []
            for id in multicamera_tracks.keys():
                id_cams = multicamera_tracks[id][0]
                if len(id_cams) > 1:
                    continue
                for id_cam in id_cams:
                    track = [x for x in tracks if x.id == id_cam]
                    if len(track) > 0:
                        detections_on_frame = [x for x in track[0].detections if x.frame == n_frame]
                        for detec in detections_on_frame:
                            detec_bboxes.append(detec.bbox)
                            detec_ids.append(id)

            gt_on_frame = [x for x in gt_list if x.frame == n_frame]

            gt_bboxes = []
            gt_ids = []
            for gt in gt_on_frame:
                gt_bboxes.append(gt.bbox)
                gt_ids.append(gt.track_id)

            # detec_bboxes = []
            # detec_ids = []
            # for det in detections_on_frame:
            #     detec_bboxes.append(det.bbox)
            #     detec_ids.append(det.track_id)

            mm_gt_bboxes = [[(bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2, bbox[2] - bbox[0], bbox[3] - bbox[1]] for
                            bbox in gt_bboxes]
            mm_detec_bboxes = [[(bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2, bbox[2] - bbox[0], bbox[3] - bbox[1]]
                               for bbox in detec_bboxes]
            distances_gt_det = mm.distances.iou_matrix(mm_gt_bboxes, mm_detec_bboxes, max_iou=1.)
            acc.update(gt_ids, detec_ids, distances_gt_det)

    print(acc.mot_events)
    mh = mm.metrics.create()
    summary = mh.compute(acc, metrics=mm.metrics.motchallenge_metrics, name='acc')
    print(summary.to_string())

